public class looping {
    public static void main(String[] args) {
        // for (int i=1; i<=10; i++){
        //     System.out.printf("Halo %d-kali\n", i);
        // }
        String depan = "Nabilah";
        String belakang = "Lianda";
        for (int i=0; i<5; i++){
            System.out.println(depan);
        };
        for (int i=0; i<5; i++){
            System.out.println(belakang);
        }
    }
}