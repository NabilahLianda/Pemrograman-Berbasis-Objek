public class MainElips {
    public static void main(String[] args) {
        Elips bundar1 = new Elips();
        bundar1.setA(14);
        bundar1.setB(7);
        System.out.println("Radius a = " + bundar1.getA());
        System.out.println("Radius b = " + bundar1.getB());
        System.out.println("Luas Elips = " + bundar1.getLuas());
        System.out.println("Keliling Elips = " + bundar1.getKeliling());
    }
}