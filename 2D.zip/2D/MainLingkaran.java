public class MainLingkaran {
    public static void main(String[] args) {
        Lingkaran bundar1 = new Lingkaran();
        bundar1.setRadius(14);
        System.out.println("Radius Lingkaran = " + bundar1.getRadius());
        System.out.println("Luas Lingkaran = " + bundar1.getLuas());
        System.out.println("Keliling Lingkaran = " + bundar1.getKeliling());
    }
}