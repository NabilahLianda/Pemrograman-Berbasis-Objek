interface A{
    public void methodA();
}