class Penguin extends Bird {
    public void fly() {
        System.out.println("No thanks. I'd rather swimming");
    }
}