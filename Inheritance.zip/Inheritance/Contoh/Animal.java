public class Animal{
    String name;
    public Animal(){
        System.out.println("I am an animal");
    }

    public void speak (){
        System.out.println("Hello");
    }
}