interface C extends A{
    public void methodC();
}