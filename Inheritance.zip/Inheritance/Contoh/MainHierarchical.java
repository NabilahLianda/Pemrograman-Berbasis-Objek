public class MainHierarchical {
    public static void main(String[] args) {
        Animal a = new Animal();
        a.speak();
        
        Bird b = new Bird();
        b.speak();

        Cat c = new Cat();
        c.speak();
    }
}