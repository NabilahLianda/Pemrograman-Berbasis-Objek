public class MainHybird {
    public static void main(String[] args) {
        D obj1 = new D();
        obj1.methodA();
        obj1.methodB();
        obj1.methodC();
    }
}