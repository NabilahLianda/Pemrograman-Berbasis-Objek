interface B extends A{
    public void methodB();
}